
import SwiftUI

struct ContentView: View {
    @StateObject var state = BrowserState()
    @State var tabs = [BrowserTab(url:"https://google.com")]
    @State var current: UUID = UUID()

    var body: some View {
        VStack {
            TabsView(tabs: $tabs, current: $current)
            let tab = tabs.first ?? BrowserTab(url:"https://google.com")
            BrowserView(state: state, urlString: tab.url)
            Toolbar(
                back:{}, forward:{}, refresh:{}, home:{}, state: state
            )
        }
        .tunaDark()
    }
}
