
import Foundation

class iCloudSync {
    static func enable() {
        let path = FileManager.default.url(forUbiquityContainerIdentifier: nil)
        print("iCloud path:", path?.path ?? "none")
    }
}
