
import Foundation

class BrowserState: ObservableObject {
    @Published var desktopMode = false

    var desktopAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15)"
    var mobileAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17)"

    func agent() -> String {
        desktopMode ? desktopAgent : mobileAgent
    }
}
