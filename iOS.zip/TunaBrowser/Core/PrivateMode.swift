
class PrivateMode {
    static let shared = PrivateMode()
    var enabled = false
}
