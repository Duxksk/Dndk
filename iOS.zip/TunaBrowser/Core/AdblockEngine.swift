
import Foundation
import WebKit

class AdblockEngine {
    static let shared = AdblockEngine()
    private let blockList = [
        "ads.", "doubleclick.net", "googlesyndication.com",
        "banner", "popunder", "facebook.net/tr/"
    ]
    func shouldBlock(_ url: URL?) -> Bool {
        guard let u = url?.absoluteString.lowercased() else { return false }
        return blockList.contains { u.contains($0) }
    }
}
