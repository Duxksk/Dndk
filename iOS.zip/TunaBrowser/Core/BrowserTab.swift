
import Foundation

struct BrowserTab: Identifiable {
    let id = UUID()
    var url: String
    var title: String = "New Tab"
    var isPrivate: Bool = false
}
