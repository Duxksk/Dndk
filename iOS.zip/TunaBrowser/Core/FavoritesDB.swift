
import SQLite3
import Foundation

class FavoritesDB {
    static let shared = FavoritesDB()
    private var db: OpaquePointer?

    init() {
        let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("favorites.sqlite").path
        sqlite3_open(path, &db)
        sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS fav(id INTEGER PRIMARY KEY, url TEXT, title TEXT)", nil, nil, nil)
    }

    func add(url: String, title: String) {
        var stmt: OpaquePointer?
        sqlite3_prepare_v2(db, "INSERT INTO fav(url,title) VALUES(?,?)", -1, &stmt, nil)
        sqlite3_bind_text(stmt, 1, url, -1, nil)
        sqlite3_bind_text(stmt, 2, title, -1, nil)
        sqlite3_step(stmt)
    }

    func list() -> [(String,String)] {
        var arr: [(String,String)] = []
        var stmt: OpaquePointer?
        sqlite3_prepare_v2(db, "SELECT url,title FROM fav", -1, &stmt, nil)
        while sqlite3_step(stmt) == SQLITE_ROW {
            arr.append((
                String(cString: sqlite3_column_text(stmt, 0)),
                String(cString: sqlite3_column_text(stmt, 1))
            ))
        }
        return arr
    }
}
