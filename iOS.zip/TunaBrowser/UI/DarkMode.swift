
import SwiftUI

struct DarkModeModifier: ViewModifier {
    @Environment(\.colorScheme) var scheme
    func body(content: Content) -> some View {
        content.background(scheme == .dark ? Color.black : Color.white)
    }
}
extension View {
    func tunaDark() -> some View { self.modifier(DarkModeModifier()) }
}
