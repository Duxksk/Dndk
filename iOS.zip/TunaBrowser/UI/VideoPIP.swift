
import AVKit
import WebKit

func enablePIP(for webView: WKWebView) {
    AVPictureInPictureController.shared?.startPictureInPicture()
}
