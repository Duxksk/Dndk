
import SwiftUI
import WebKit

class WebViewCoordinator: NSObject, WKNavigationDelegate {
    var parent: BrowserView
    init(_ p: BrowserView) { parent = p }

    func webView(_ webView: WKWebView, decidePolicyFor nav: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if AdblockEngine.shared.shouldBlock(nav.request.url) {
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }
}

struct BrowserView: UIViewRepresentable {
    @ObservedObject var state: BrowserState
    var urlString: String
    let webView = WKWebView()

    func makeUIView(context: Context) -> WKWebView {
        webView.navigationDelegate = context.coordinator
        webView.customUserAgent = state.agent()
        loadURL()
        return webView
    }

    func updateUIView(_ view: WKWebView, context: Context) {
        view.customUserAgent = state.agent()
    }

    func loadURL() {
        if let u = URL(string: urlString) {
            webView.load(URLRequest(url: u))
        }
    }

    func makeCoordinator() -> WebViewCoordinator { WebViewCoordinator(self) }
}
