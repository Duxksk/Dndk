
import SwiftUI

struct Toolbar: View {
    var back: ()->Void
    var forward: ()->Void
    var refresh: ()->Void
    var home: ()->Void
    @ObservedObject var state: BrowserState

    var body: some View {
        HStack {
            Button("◀︎", action: back)
            Spacer()
            Button("▶︎", action: forward)
            Spacer()
            Button("⟳", action: refresh)
            Spacer()
            Button("홈", action: home)
            Spacer()
            Toggle("데스크톱", isOn: $state.desktopMode).labelsHidden()
        }
        .padding()
        .background(Color(red:1, green:0, blue:0).gradient.opacity(0.6)
                    .overlay(Color.blue.gradient.opacity(0.6), blendMode: .plusLighter))
    }
}
