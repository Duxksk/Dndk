
import SwiftUI

struct TabsView: View {
    @Binding var tabs: [BrowserTab]
    @Binding var current: UUID

    var body: some View {
        ScrollView(.horizontal) {
            HStack {
                ForEach(tabs) { tab in
                    Text(tab.title)
                        .padding(8)
                        .background(current == tab.id ? Color.blue.opacity(0.4) : Color.gray.opacity(0.1))
                        .cornerRadius(8)
                        .onTapGesture { current = tab.id }
                }
                Button("+") {
                    tabs.append(BrowserTab(url: "https://google.com"))
                }
            }
        }
        .padding()
    }
}
