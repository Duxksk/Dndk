// DesktopMode/UserAgentManager.swift placeholder for full implementation
