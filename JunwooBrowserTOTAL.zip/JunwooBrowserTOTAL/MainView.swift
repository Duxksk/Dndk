import SwiftUI
struct MainView: View { var body: some View { Text("Junwoo TOTAL Browser Loaded") } }
